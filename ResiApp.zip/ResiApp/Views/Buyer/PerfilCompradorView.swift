//
//  PerfilCompradorView.swift
//  ResiApp
//
//  Created by Dev Jr.23 on 5/5/26.
//

import SwiftUI
import SwiftData
import PhotosUI
internal import MapKit

struct PerfilCompradorView: View {
    @AppStorage("userRole") private var userRole: String = ""
    @Environment(\.modelContext) private var modelContext

    @Query private var perfiles: [BuyerProfile]
    @Query private var matches: [Match]

    @State private var mostrarConfirmacion = false
    @State private var pickerItem: PhotosPickerItem?
    @State private var aparecer = false

    private var perfil: BuyerProfile? { perfiles.first }

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()

            if let perfil {
                VStack(spacing: 0) {
                    headerCompacto(perfil)
                    statsRow
                    miniMapa(perfil)
                    matchesList
                    Spacer(minLength: 0)
                    botonCambiarRol
                }
            } else {
                ProgressView("Cargando perfil…")
            }
        }
        .onAppear { withAnimation(AppAnimation.easeSnap) { aparecer = true } }
        .alert("¿Cambiar rol?", isPresented: $mostrarConfirmacion) {
            Button("Cancelar", role: .cancel) {}
            Button("Cambiar", role: .destructive) { userRole = "" }
        } message: {
            Text("Volverás a la pantalla de selección de rol.")
        }
        .onChange(of: pickerItem) { _, newItem in
            Task { await cargarFoto(newItem) }
        }
    }

    // MARK: - Header

    @ViewBuilder
    private func headerCompacto(_ perfil: BuyerProfile) -> some View {
        VStack(spacing: 14) {
            PhotosPicker(selection: $pickerItem, matching: .images) {
                ZStack(alignment: .bottomTrailing) {
                    avatarView(perfil).frame(width: 96, height: 96)
                    ZStack {
                        Circle().fill(Color.appBlue).frame(width: 28, height: 28)
                        Image(systemName: "camera.fill")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    .overlay(Circle().strokeBorder(Color(.systemGroupedBackground), lineWidth: 3))
                    .offset(x: 2, y: 2)
                }
            }
            .buttonStyle(.plain)

            VStack(spacing: 2) {
                Text(perfil.nombre)
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.primary)

                Text(perfil.telefono)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
        }
        .padding(.top, 24)
        .padding(.bottom, 20)
        .frame(maxWidth: .infinity)
        .opacity(aparecer ? 1 : 0)
        .offset(y: aparecer ? 0 : -10)
    }

    @ViewBuilder
    private func avatarView(_ perfil: BuyerProfile) -> some View {
        Group {
            if let data = perfil.fotoPerfilData, let img = UIImage(data: data) {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                ZStack {
                    Circle().fill(LinearGradient(
                        colors: [Color.appBlue, Color.appBlueDark],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    Text("🏭").font(.system(size: 44))
                }
            }
        }
        .clipShape(Circle())
        .shadow(color: .black.opacity(0.1), radius: 8, y: 3)
    }

    // MARK: - Stats

    private var statsRow: some View {
        HStack(spacing: 10) {
            statCard(valor: "\(matches.count)", label: "Matches", color: .appBlue)
            statCard(
                valor: "\(matches.filter { $0.estado == .confirmado }.count)",
                label: "Confirmados", color: .appGreen
            )
            statCard(
                valor: "\(matches.filter { $0.estado == .propuesto }.count)",
                label: "Pendientes", color: .orange
            )
        }
        .padding(.horizontal, 16)
    }

    @ViewBuilder
    private func statCard(valor: String, label: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Text(valor)
                .font(.title2.weight(.bold))
                .foregroundStyle(color)
                .monospacedDigit()
            Text(label)
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    // MARK: - Mini mapa (diferenciador del comprador)

    @ViewBuilder
    private func miniMapa(_ perfil: BuyerProfile) -> some View {
        let coord = CLLocationCoordinate2D(latitude: perfil.latitud, longitude: perfil.longitud)
        let region = MKCoordinateRegion(
            center: coord,
            span: MKCoordinateSpan(latitudeDelta: 0.012, longitudeDelta: 0.012)
        )

        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Mi ubicación")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                    .tracking(0.5)
                Spacer()
                Image(systemName: "house.fill")
                    .font(.caption)
                    .foregroundStyle(.appBlue)
            }
            .padding(.horizontal, 20)
            .padding(.top, 22)

            ZStack(alignment: .bottomLeading) {
                Map(coordinateRegion: .constant(region),
                    annotationItems: [BuyerMapPinSimple(coordinate: coord)]) { pin in
                    MapMarker(coordinate: pin.coordinate, tint: .appBlue)
                }
                .frame(height: 130)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .allowsHitTesting(false)

                Text(perfil.direccion)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(.regularMaterial, in: Capsule())
                    .padding(10)
            }
            .padding(.horizontal, 16)
        }
    }

    // MARK: - Lista de matches

    private var matchesList: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Actividad reciente")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                    .tracking(0.5)
                Spacer()
                if !matches.isEmpty {
                    Text("\(matches.count)")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 18)
            .padding(.bottom, 8)

            if matches.isEmpty {
                emptyState
            } else {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(matches.enumerated()), id: \.element.id) { idx, match in
                            matchRow(match)
                            if idx < matches.count - 1 {
                                Divider().padding(.leading, 60)
                            }
                        }
                    }
                    .background(Color(.secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "tray")
                .font(.system(size: 32, weight: .light))
                .foregroundStyle(.tertiary)
            Text("Sin actividad")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.secondary)
            Text("Tus matches aparecerán aquí")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30)
        .padding(.horizontal, 16)
    }

    @ViewBuilder
    private func matchRow(_ match: Match) -> some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(colorEstado(match.estado).opacity(0.15))
                    .frame(width: 36, height: 36)
                Image(systemName: iconoEstado(match.estado))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(colorEstado(match.estado))
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("Match")
                    .font(.subheadline.weight(.semibold))
                Text(match.estado.rawValue.capitalized)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(match.fecha, format: .relative(presentation: .numeric))
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }

    private func iconoEstado(_ estado: MatchEstado) -> String {
        switch estado {
        case .propuesto:  return "clock.fill"
        case .confirmado: return "checkmark.circle.fill"
        case .rechazado:  return "xmark.circle.fill"
        }
    }

    private func colorEstado(_ estado: MatchEstado) -> Color {
        switch estado {
        case .propuesto:  return .orange
        case .confirmado: return .appGreen
        case .rechazado:  return .appRed
        }
    }

    // MARK: - Cambiar rol

    private var botonCambiarRol: some View {
        Button(role: .destructive) {
            mostrarConfirmacion = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 14, weight: .semibold))
                Text("Cambiar rol")
                    .font(.subheadline.weight(.semibold))
            }
            .foregroundStyle(.appRed)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(Color(.secondarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 12)
    }

    // MARK: - Foto

    private func cargarFoto(_ item: PhotosPickerItem?) async {
        guard let item, let perfil else { return }
        guard let data = try? await item.loadTransferable(type: Data.self) else { return }
        if let jpg = UIImage(data: data)?.jpegData(compressionQuality: 0.8) {
            perfil.fotoPerfilData = jpg
            try? modelContext.save()
        }
    }
}

private struct BuyerMapPinSimple: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
}
