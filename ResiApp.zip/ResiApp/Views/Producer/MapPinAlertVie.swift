//
//  MapPinAlertVie.swift
//  ResiApp
//
//  Created by Dev Jr.23 on 5/5/26.
//


import SwiftUI
import SwiftData
internal import MapKit

// MARK: - Overlay principal

struct MapCapturaOverlay: View {
    @Query(sort: \SimulatedCapture.fecha, order: .reverse)
    private var capturas: [SimulatedCapture]

    @Query private var compradores: [BuyerProfile]

    @AppStorage("userRole") private var userRole: String = ""
    @State private var capturaSeleccionada: SimulatedCapture? = nil
    @State private var mostrarContacto: Bool = false
    @State private var mostrarChat: Bool = false

    var body: some View {
        ZStack {
            MapaConPins(
                capturas: capturas,
                compradores: compradores,
                onSelectCaptura: { captura in
                    withAnimation(AppAnimation.spring) { capturaSeleccionada = captura }
                }
            )
            .ignoresSafeArea()

            // 💬 CHATBOT FAB — esquina superior izquierda
            VStack {
                HStack {
                    ChatBotButton(mostrarChat: $mostrarChat)
                        .padding(.leading, 16)
                        .padding(.top, 65)
                    Spacer()
                }
                Spacer()
            }

            if capturaSeleccionada != nil {
                Color.black.opacity(0.55)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(AppAnimation.spring) { capturaSeleccionada = nil }
                    }
                    .transition(.opacity)
            }

            if let captura = capturaSeleccionada {
                CapturaPopupCentrado(
                    captura: captura,
                    esComprador: userRole == "comprador",
                    onClose: {
                        withAnimation(AppAnimation.spring) { capturaSeleccionada = nil }
                    },
                    onContactar: {
                        capturaSeleccionada = nil
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            mostrarContacto = true
                        }
                    }
                )
                .transition(.scale(scale: 0.85).combined(with: .opacity))
            }
        }
        .fullScreenCover(isPresented: $mostrarContacto) {
            ContactoSimuladoView(
                nombreContacto: "Productor",
                telefono: "+52 55 1234 5678",
                onClose: { mostrarContacto = false }
            )
        }
        .sheet(isPresented: $mostrarChat) {
            // Conecta aquí tu ChatBotView
            Text("Chat Bot")
        }
    }
}

// MARK: - ChatBot FAB

struct ChatBotButton: View {
    @Binding var mostrarChat: Bool
    @State private var pulsing = false

    var body: some View {
        Button(action: { mostrarChat = true }) {
            ZStack {
                // Anillo pulsante verde
                Circle()
                    .fill(Color(red: 0.07, green: 0.72, blue: 0.38).opacity(0.22))
                    .frame(width: 56, height: 56)
                    .scaleEffect(pulsing ? 1.35 : 0.9)
                    .animation(
                        .easeInOut(duration: 1.5).repeatForever(autoreverses: true),
                        value: pulsing
                    )

                // Círculo principal
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.07, green: 0.82, blue: 0.45),
                                Color(red: 0.04, green: 0.58, blue: 0.32)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 44, height: 44)
                    .shadow(
                        color: Color(red: 0.07, green: 0.72, blue: 0.38).opacity(0.5),
                        radius: 8, y: 4
                    )

                Image(systemName: "message.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white)
            }
        }
        .onAppear { pulsing = true }
    }
}

// MARK: - Mapa UIKit con pins (capturas + compradores)

struct MapaConPins: UIViewRepresentable {
    let capturas: [SimulatedCapture]
    let compradores: [BuyerProfile]
    var onSelectCaptura: (SimulatedCapture) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onSelect: onSelectCaptura, capturas: capturas)
    }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.showsUserLocation = true
        map.register(CapturaAnnotationView.self,
                     forAnnotationViewWithReuseIdentifier: CapturaAnnotationView.reuseID)
        map.register(BuyerAnnotationView.self,
                     forAnnotationViewWithReuseIdentifier: BuyerAnnotationView.reuseID)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        let viejas = map.annotations.filter {
            $0 is CapturaAnnotation || $0 is BuyerAnnotation
        }
        map.removeAnnotations(viejas)

        let pinsCaptura = capturas.map {
            CapturaAnnotation(
                coordinate: CLLocationCoordinate2D(latitude: $0.coordLatitud, longitude: $0.coordLongitud),
                capturaId: $0.id
            )
        }
        map.addAnnotations(pinsCaptura)

        let pinsBuyer = compradores.map {
            BuyerAnnotation(
                coordinate: CLLocationCoordinate2D(latitude: $0.latitud, longitude: $0.longitud),
                nombre: $0.nombre,
                direccion: $0.direccion
            )
        }
        map.addAnnotations(pinsBuyer)

        context.coordinator.capturas = capturas
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        var onSelect: (SimulatedCapture) -> Void
        var capturas: [SimulatedCapture]

        init(onSelect: @escaping (SimulatedCapture) -> Void, capturas: [SimulatedCapture]) {
            self.onSelect = onSelect; self.capturas = capturas
        }

        func mapView(_ map: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            if let ann = annotation as? CapturaAnnotation {
                let v = map.dequeueReusableAnnotationView(
                    withIdentifier: CapturaAnnotationView.reuseID, for: ann) as? CapturaAnnotationView
                v?.configure()
                return v
            }
            if let ann = annotation as? BuyerAnnotation {
                let v = map.dequeueReusableAnnotationView(
                    withIdentifier: BuyerAnnotationView.reuseID, for: ann) as? BuyerAnnotationView
                v?.configure()
                v?.canShowCallout = true
                return v
            }
            return nil
        }

        func mapView(_ map: MKMapView, didSelect view: MKAnnotationView) {
            guard let ann = view.annotation as? CapturaAnnotation,
                  let cap = capturas.first(where: { $0.id == ann.capturaId }) else { return }
            map.deselectAnnotation(ann, animated: false)
            onSelect(cap)
        }
    }
}

// MARK: - Annotations

final class CapturaAnnotation: NSObject, MKAnnotation {
    let coordinate: CLLocationCoordinate2D
    let capturaId: UUID
    init(coordinate: CLLocationCoordinate2D, capturaId: UUID) {
        self.coordinate = coordinate; self.capturaId = capturaId
    }
}

final class BuyerAnnotation: NSObject, MKAnnotation {
    let coordinate: CLLocationCoordinate2D
    let title: String?
    let subtitle: String?

    init(coordinate: CLLocationCoordinate2D, nombre: String, direccion: String) {
        self.coordinate = coordinate
        self.title = nombre
        self.subtitle = direccion
    }
}

// MARK: - Pin verde pulsante (capturas = oportunidad)

final class CapturaAnnotationView: MKAnnotationView {
    static let reuseID = "CapturaAnnotationView"
    private let size: CGFloat = 40

    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        frame = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        centerOffset = CGPoint(x: 0, y: -size / 2)
        backgroundColor = .clear
    }
    required init?(coder: NSCoder) { fatalError() }

    func configure() {
        subviews.forEach { $0.removeFromSuperview() }
        layer.sublayers?.forEach { $0.removeFromSuperlayer() }

        // Anillo pulsante verde oportunidad
        let pulse = CALayer()
        pulse.frame = bounds
        pulse.cornerRadius = size / 2
        pulse.backgroundColor = UIColor(red: 0.07, green: 0.72, blue: 0.38, alpha: 0.25).cgColor
        layer.insertSublayer(pulse, at: 0)
        let anim = CABasicAnimation(keyPath: "transform.scale")
        anim.fromValue = 0.8; anim.toValue = 1.4
        anim.duration = 1.1; anim.autoreverses = true; anim.repeatCount = .infinity
        pulse.add(anim, forKey: "pulse")

        // Círculo verde esmeralda
        let circle = UIView(frame: CGRect(x: 7, y: 7, width: size - 14, height: size - 14))
        circle.backgroundColor = UIColor(red: 0.07, green: 0.72, blue: 0.38, alpha: 1)
        circle.layer.cornerRadius = (size - 14) / 2
        addSubview(circle)

        let icon = UIImageView(image: UIImage(systemName: "exclamationmark"))
        icon.tintColor = .white
        icon.contentMode = .scaleAspectFit
        icon.frame = CGRect(x: 12, y: 10, width: size - 24, height: size - 20)
        addSubview(icon)
    }
}

// MARK: - Pin azul tienda (comprador)

final class BuyerAnnotationView: MKAnnotationView {
    static let reuseID = "BuyerAnnotationView"
    private let size: CGFloat = 44

    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        frame = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        centerOffset = CGPoint(x: 0, y: -size / 2)
        backgroundColor = .clear
    }
    required init?(coder: NSCoder) { fatalError() }

    func configure() {
        subviews.forEach { $0.removeFromSuperview() }
        layer.sublayers?.forEach { $0.removeFromSuperlayer() }

        // Anillo blanco con sombra
        let ring = UIView(frame: bounds)
        ring.backgroundColor = .white
        ring.layer.cornerRadius = size / 2
        ring.layer.shadowColor = UIColor.black.cgColor
        ring.layer.shadowOpacity = 0.3
        ring.layer.shadowRadius = 6
        ring.layer.shadowOffset = CGSize(width: 0, height: 3)
        addSubview(ring)

        // Círculo azul interior
        let inset: CGFloat = 4
        let circle = UIView(frame: CGRect(x: inset, y: inset, width: size - inset * 2, height: size - inset * 2))
        circle.backgroundColor = UIColor(red: 0.10, green: 0.45, blue: 0.90, alpha: 1)
        circle.layer.cornerRadius = (size - inset * 2) / 2
        addSubview(circle)

        // Ícono de tienda (storefront)
        let icon = UIImageView(image: UIImage(systemName: "storefront.fill"))
        icon.tintColor = .white
        icon.contentMode = .scaleAspectFit
        let iconSize: CGFloat = 20
        icon.frame = CGRect(
            x: (size - iconSize) / 2,
            y: (size - iconSize) / 2,
            width: iconSize,
            height: iconSize
        )
        addSubview(icon)
    }
}

// MARK: - Popup centrado

struct CapturaPopupCentrado: View {
    let captura: SimulatedCapture
    let esComprador: Bool
    let onClose: () -> Void
    let onContactar: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .top) {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.circle.fill").font(.caption)
                    Text("OPORTUNIDAD").font(.caption.weight(.black)).tracking(1)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(Color(red: 0.07, green: 0.72, blue: 0.38), in: Capsule())

                Spacer()

                Button(action: onClose) {
                    Image(systemName: "xmark")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.primary.opacity(0.6))
                        .frame(width: 30, height: 30)
                        .background(Color.primary.opacity(0.08), in: Circle())
                }
            }
            .padding(.horizontal, 20).padding(.top, 18)

            VStack(alignment: .leading, spacing: 4) {
                Text("Captura de estiércol")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.primary)
                Text(captura.fecha, style: .date)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 20).padding(.top, 12)

            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color.primary.opacity(0.06))
                    .frame(height: 130)
                VStack(spacing: 8) {
                    Image(systemName: "photo.fill")
                        .font(.system(size: 32))
                        .foregroundStyle(.secondary.opacity(0.5))
                    Text("Imagen no disponible aún")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 20).padding(.top, 14)

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                datoCard(emoji: emojiAnimal(captura.animal), titulo: "Animal",   valor: captura.animal)
                datoCard(emoji: "💧", titulo: "Humedad",  valor: String(format: "%.0f%%", captura.humedadPct))
                datoCard(emoji: "📦", titulo: "Volumen",  valor: String(format: "%.0f m³", captura.volumenM3))
                datoCard(emoji: "🌾", titulo: "Alimento", valor: captura.alimento)
            }
            .padding(.horizontal, 20).padding(.top, 14)

            if esComprador {
                Button(action: onContactar) {
                    HStack(spacing: 8) {
                        Image(systemName: "phone.fill")
                        Text("Simular contacto").fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.appBlue)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .padding(.horizontal, 20)
                .padding(.top, 18)
            }

            HStack(spacing: 6) {
                Image(systemName: "location.fill")
                    .font(.caption2)
                    .foregroundStyle(Color(red: 0.07, green: 0.72, blue: 0.38))
                Text(String(format: "%.5f, %.5f", captura.coordLatitud, captura.coordLongitud))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            .padding(.top, 14).padding(.bottom, 20)
        }
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(.regularMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.4), lineWidth: 0.5)
                )
        )
        .shadow(color: .black.opacity(0.35), radius: 30, y: 12)
        .padding(.horizontal, 24)
    }

    @ViewBuilder
    private func datoCard(emoji: String, titulo: String, valor: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 5) {
                Text(emoji).font(.body)
                Text(titulo)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                    .tracking(0.5)
            }
            Text(valor)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.primary)
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.primary.opacity(0.05))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .strokeBorder(Color.primary.opacity(0.08), lineWidth: 1)
                )
        )
    }

    private func emojiAnimal(_ raw: String) -> String {
        if raw.contains("Bovino")  { return "🐄" }
        if raw.contains("Porcino") { return "🐷" }
        if raw.contains("Aviar")   { return "🐔" }
        if raw.contains("Equino")  { return "🐴" }
        if raw.contains("Ovino")   { return "🐑" }
        return "🐾"
    }
}
